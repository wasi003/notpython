# 1. Histogram 
# Creating a dataset of student marks 
student_marks <- c(55, 65, 70, 72, 73, 90, 95, 100, 75) 
# Plotting a Histogram 
hist(student_marks, 
     main = "Histogram of Student Marks", 
     xlab = "Marks", 
     ylab = "Frequency", 
     col = "lightblue", 
     border = "black") 
# 2. Bar Plot 
# Creating a dataset of student names and marks 
student_names <- c("John", "Alice", "Bob", "Emma", "Lily") 
student_scores <- c(45, 55, 65, 55, 35) 
# Plotting a Bar Plot 
barplot(student_scores, 
        names.arg = student_names, 
        main = "Bar Plot of Student Scores", 
        xlab = "Students", 
        ylab = "Scores", 
        col = "lightgreen", 
        border = "black")
# 3. Line Chart 
# Creating a dataset of monthly temperatures 
months<-c(1,2,3,4,5) 
temperature <- c(10, 15, 5, 20, 28) 
# Plotting a Line Chart 
plot(months, temperature, 
     type = "o", 
     col = "blue", 
     main = "Line Chart of Monthly Temperatures", 
     xlab = "Months", 
     ylab = "Temperature (°C)") 
# 4. Pie Chart 
# Creating a dataset of department-wise students 
dept <- c("IT", "Math", "Physics", "Biology") 
students <- c(120, 80, 60, 40) 
# Plotting a Pie Chart 
pie(students, 
    labels = dept, 
    main = "Pie Chart of Department-Wise Students", 
    col = rainbow(length(dept))) 
# 5. Box Plot 
# Creating a dataset of exam scores 
exam_scores <- c(55, 65, 70, 80, 85, 90, 95, 100, 50, 75) 
# Plotting a Box Plot 
boxplot(exam_scores, 
        main = "Box Plot of Exam Scores", 
        ylab = "Scores", 
        col = "lightcoral", 
        border = "black") 
# 6. Scatter Plot 
# Creating datasets for height and weight 
height <- c(150, 160, 165, 170, 175) 
weight <- c(50, 55, 60, 65, 70) 
# Plotting a Scatter Plot 
plot(height, weight,
     main = "Scatter Plot of Height vs. Weight", 
     xlab = "Height (cm)", 
     ylab = "Weight (kg)", 
     pch = 16, 
     col = "darkred")