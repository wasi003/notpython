#1. Creating vector
n=c(1.2,3.4,5.6,7.8)
cat("Vector created :\n")
cat("Numeric vector : ",n,"\n\n")

#2. Accessing Elements 

cat("Accessing Elements:\n") 
cat("First element of numeric_vector:", n[1], "\n") 
cat("Elements greater than 3 in numeric_vector:", n[n > 3], "\n") 
cat("Second to third elements in numeric_vector:", n[2:3], "\n\n")

# 3. Vector Operations 
# Arithmetic Operations on Numeric Vectors 
sum_vector <- n + 2 
product_vector <- n * 2 
cat("Vector Operations:\n") 
cat("Sum of numeric_vector + 2:", sum_vector, "\n") 
cat("Product of numeric_vector * 2:", product_vector, "\n\n")

# 4. Manipulating Vectors 
cat("Manipulating Vectors:\n") 
# Adding a new element 
n <- c(n, 9.0) 
cat("Numeric Vector after adding 9.0:", n, "\n")
# Modifying an element 
n[2] <- 4.5 
cat("Numeric Vector after modifying second element:", n, "\n") 
# Removing the first element 
n <- n[-1] 
cat("Numeric Vector after removing the first element:", n, "\n\n")

# 5. Vector Functions 
cat("Vector Functions:\n") 
cat("Sum of elements in numeric_vector:", sum(n), "\n") 
cat("Length of numeric_vector:", length(n), "\n") 
cat("Mean of numeric_vector:", mean(n), "\n")