# Step 1: Define the data 
# For Bar Chart 
categories <- c("A", "B", "C", "D") 
values <- c(10, 20, 15, 25) 
# For Histogram 
data <- c(5, 7, 8, 9, 10, 10, 12, 14, 15, 16, 17, 20) 
# For Scatter Plot 
x <- c(1, 2, 3, 4, 5) 
y <- c(2, 3, 5, 7, 11) 
# Step 2: Create a Bar Chart 
barplot(values, names.arg = categories, main = "Bar Chart of Categories", xlab = "Categories", ylab 
        = "Values", col = "blue") 
# Step 3: Create a Histogram 
hist(data, breaks = 5, main = "Histogram of Data", xlab = "Values", ylab = "Frequency", col = 
       "green") 
# Step 4: Create a Scatter Plot 
plot(x, y, main = "Scatter Plot of X vs Y", xlab = "X", ylab = "Y", pch = 19, col = "red")