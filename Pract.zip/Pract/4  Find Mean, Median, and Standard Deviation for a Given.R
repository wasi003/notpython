# Step 1: Define the discrete probability distribution 
values <- c(1, 2, 3, 4, 5) # Given values 
probabilities <- c(0.1, 0.2, 0.3, 0.2, 0.2) # Corresponding probabilities 
# Step 2: Calculate the Mean 
mean_value <- sum(values * probabilities) 
# Step 3: Calculate the Median 
median_value <- median(rep(values, probabilities * 100)) 
# Step 4: Calculate the Standard Deviation 
variance <- sum((values - mean_value)^2 * probabilities) 
std_dev <- sqrt(variance) 
# Output the results 
cat("Mean:", mean_value, "\n") 
cat("Median:", median_value, "\n") 
cat("Standard Deviation:", std_dev, "\n")