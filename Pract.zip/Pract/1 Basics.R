#1. data types
num=10.5
int=7L
char="R Programming"
log=TRUE
cat("Data types : \n")
cat("Numeric variables :",num,"Type : ",typeof(num),"\n")
cat("Integer variables :",int,"Type : ",typeof(int),"\n")
cat("Character variables :",char,"Type : ",typeof(char),"\n")
cat("Logical variables :",log,"Type : ",typeof(log),"\n\n")

#2. variables ,arithmetic operations
a=5
b=3
sum=a+b
diff=a-b
pro=a*b
quo=a/b
cat("Arithmetic operations : \n")
cat("sum : ",sum,"\n")
cat("Difference : ",diff,"\n")
cat("Product : ",pro,"\n")
cat("Quotient : ",quo,"\n\n")

#3. Operators
#Relational operations
equal=(a==b)
greater=(a>b)

cat("Relation operations : \n")
cat("Is Equal : ",equal,"\n")
cat("Is Greater : ",greater,"\n\n")

#Logical operations
and=(a>2)&(b<5)
or=(a>2)|(b<1)

cat("Logical Operations : \n")
cat("Logical AND : ",and,"\n")
cat("Logical OR : ",or,"\n\n")

#4. Control Statement

cat("Control Statement : \n")

#IF-Else statement
if (a>b){
  cat("a is greater than b\n")
}else{
  cat("a is not greater than b\n\n")
}

#FOR Loop
cat("For loop : \n")
for (i in 1:3){
  cat("Iteration : ",i,"\n\n")
}

#5. Functions
add=function(x,y){
  return(x+y)
}
result=add(10,15)
cat("Function Result : \n")
cat("sum of 10 and 15 is :",result,"\n\n")