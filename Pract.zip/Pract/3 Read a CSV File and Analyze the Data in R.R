# 1. Reading the CSV File "sample_data.csv" 
data <- read.csv("sample_data.csv") 
# 2. Display the Preview and Summary of the data (first five records) 
cat("Data Preview:\n") 
print(head(data,5)) 
cat("\nSummary of the Data:\n") 
print(summary(data)) 
# 3. Analyzing the Data 
# Calculate mean, median, and mode for a numeric column (Assuming 'Age' column exists) 
cat("\nBasic Analysis:\n") 
age_mean <- mean(data$Age, na.rm = TRUE) 
age_median <- median(data$Age, na.rm = TRUE) 
age_mode <- as.numeric(names(sort(table(data$Age), decreasing=TRUE)[1])) 
cat("Mean Age:", age_mean, "\n") 
cat("Median Age:", age_median, "\n") 
cat("Mode Age:", age_mode, "\n\n") 
# Generate a frequency table for Gender column 
gender_table <- table(data$Gender) 
cat("Gender Distribution:\n") 
print(gender_table) 
# Visualize the data using a simple bar plot for 'Gender' 
barplot(gender_table, main = "Gender Distribution", col = "lightblue")

sample_data.csv: 
      ID,Name,Age,Gender,Salary 
      1,John,28,Male,50000 
      2,Emma,32,Female,60000 
      3,Alex,25,Male,45000 
      4,Maria,29,Female,52000 
      5,James,31,Male,55000 
      6,Sophia,30,Female,58000 
      7,Chris,26,Male,47000 
      8,Linda,33,Female,61000 
      9,David,31,Male,48000