#creating the matrix
#create a matrix -1
m1=matrix(c(1:9),3,3,TRUE)
cat("matrix x-1")
print(m1)
#create a matirx-2
m2=matrix(c(1,2,3,0,1,2,1,1,3),3,3,TRUE)
cat("matrix-2\n")
print(m2)

#Accessing
cat ("ascessing the elements\n")
a1<-m1 [2,3]
cat("The element in the matrix-1 at (2,3))is",a1,"\n")
a2=m2[,]
cat ("The Second row of the matrix-2is", a2,"\n")
a3=m1[,3]
cat("The third column at matrix -1 is", a3,"\n")
      
#matrix operations
cat ("matrix operations in")
additn =m1+m2
cat("addition of the matrix is \n")
print(additn)
a2=m1-m2
cat ("subtraction of the matrix is \n")
print(a2)
a3=m1*m2
cat("The matrix multplication {element wise}is \n")
print(a3)
a4=m1%*%m2
cat("matrix multiplication is \n")
print(a4)