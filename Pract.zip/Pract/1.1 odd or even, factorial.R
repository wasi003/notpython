#1.1 odd or even
cat("Program to find the number is even or odd")
n=as.numeric(readline("Enter a number : "))
if (n%%2==0){
  cat("The number ",n,"is even")
}else{
  cat("The number ",n,"is odd\n\n")}

#1.2 factorial
cat("Program to find the factorial of the number ")
n=as.numeric(readline("Enter a number : "))
multi=1
for (i in 1:n){
  multi=multi*i
}
cat("The factorial of",n,"is",multi)